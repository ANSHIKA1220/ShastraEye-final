import numpy as np
from tensorflow.keras.models import load_model
from collections import deque
import cv2

model = load_model("violence_detection_model.h5")
labels = ['Fights', 'NoFights']
IMG_SIZE = 64

def fight_detector(frame_buffer: deque):
    frames = [cv2.resize(f, (IMG_SIZE, IMG_SIZE)).astype("float32") / 255.0 for f in frame_buffer]
    input_frames = np.array(frames).reshape(1, 16, IMG_SIZE, IMG_SIZE, 3)
    prediction = model.predict(input_frames, verbose=0)
    label = labels[np.argmax(prediction)]
    return label