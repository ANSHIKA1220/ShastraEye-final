import cv2
import numpy as np

net = cv2.dnn.readNetFromDarknet("yolov3_testing.cfg", "yolov3_training_2000.weights")

classes = ["Weapon"]

def weapon_detector(frame):
    height, width = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, 0.00392, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    layer_names = net.getLayerNames()
    output_layers = [layer_names[i - 1] for i in net.getUnconnectedOutLayers()]
    outs = net.forward(output_layers)

    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                return "Weapon"
    return "No Weapon"