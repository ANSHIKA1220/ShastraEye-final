import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_email_alert(subject, message):
    sender_email = "anshikashrivastava0304@gmail.com"
    receiver_email = "anshikashrivastava0304@gmail.com"
    app_password = "uesgtvzfujqetvim"  # Use Gmail App Password here

    # Email setup
    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Subject"] = subject

    msg.attach(MIMEText(message, "plain"))

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(sender_email, app_password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
            print("[📧] Email alert sent successfully.")
    except Exception as e:
        print("[❌] Failed to send email alert:", e)
